<div class="row demosrs" id='showfbaddsdata'>
    <section id="contentrs">
        <div id="container" class="clearfix" style="padding: 5px; margin-bottom: 20px; border-radius: 5px; clear: both; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;">
            <div class="row">
                <?php
                if (!empty($allofferfeed)) {
                    foreach ($allofferfeed as $offer) { 
                     $date = date("m-d-y", strtotime($offer['date'])); 
                        ?>
                        <div class="row" style="background: #fff; border: 1px solid #ddd; margin: 0 auto; margin-bottom: 20px;">
                            <div class="col-md-9 col-sm-12 col-xs-12" style=" margin-bottom: 10px;"> 
                                <div class="row">
                                    <div class="col-md-3">
                                        <a class="thumbnail" style="border:none" href="#"><img style="width:200px; float: left; border: 1px solid #ddd;" class="img-responsive" src="<?php echo $offer['zip_file_name']; ?>" alt=""></a>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="row" style=" margin-top:10px">
                                            <h4><?php echo $offer['title']; ?></h4>
                                        </div>
                                        <div class="row">
                                            <span style="float: left;">URL :</span><div class="col-md-11" style="border: 1px solid #ddd;">
                                                <p><?php echo $offer['url']; ?></p>
                                            </div>
                                        </div>
                                        <div class="row thumb" style="margin-top: 10px;margin-right: -7px;">
                                            <div>
                                                <?php if (in_array($offer['id'], $favbanner)) { ?>
                                                    <span style="margin-left: 10px;"><img style="width: 14px; font-size: 10px;" src="<?php echo base_url()  ?>assets/icon/favorites.png"> FAVORITES</span>
                                                <?php } else { ?>
                                                    <a style="font-size: 10px; margin-left: 10px; color: inherit;" href="<?php echo base_url()  ?>makebannerfavorites/<?php echo $offer['id'];  ?>/1"><img src="<?php echo base_url()  ?>assets/icon/favorites.png" style="width: 14px;"> ADD TO FAVORITES</a>
                                                <?php } ?> 
                                                <span style="font-size: 10px; margin-left: 10px;" onclick="showcommentbox('<?php echo $offer['id'];  ?>');" id="landingcommbtn" landingddsid="<?php echo $offer['id'];  ?>" data-toggle="modal" data-target="#bannercommentmodal"><img src="<?php echo base_url()  ?>assets/icon/comment.png" style="color:#3079C8; width: 16px;">  <?php //echo count($allcomments);              ?> COMMENTS</span>
                                                <div class="modal fade" tabindex="-1" role="dialog" id="bannercommentmodal"></div>
                                                <span style="font-size: 10px; margin-left: 10px;"><a style="color: inherit;" href="" title="ImageName"><img src="<?php echo base_url()  ?>assets/icon/whois.png" style="width: 16px;"> WHOIS</a></span>
                                                <span style="font-size: 10px; margin-left: 10px;"><a style="color: inherit;" href="" title="ImageName"><img src="<?php echo base_url()  ?>assets/icon/contact.png" style="width: 16px;"> CONTACT</a></span>
                                                <span style="font-size: 10px; float: right; margin-right: 23px;"><?php echo $date;?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-5 col-xs-5">
                                <div class="table-responsive" style="border: 1px solid #ddd; margin-right: 3px; margin-left: -11px;">
                                    <table id="myTable" class="table table-striped" style="font-size: 12px;">
                                        <thead>
                                        </thead>
                                        <tbody>
                                            <tr><td style="text-align: center; padding: 6px 6px;"><a href="<?php echo $offer['url'];    ?>" target="_blank">VIew Site</a></td></tr>
                                            <tr><td style="padding: 6px 6px;">Category :<?php
                                                    $categoryArray = explode(',', $offer['cat_id']);
                                                     $getcategory = $this->LandingModel->getcategoryinfo($categoryArray);
                                                     $string = '';
                                                     foreach ($getcategory as $cat) {
                                                      $string[] = $cat['cat_name'];
                                                      }
                                                      echo implode(", ", $string);
                                                    ?>
                                                </td></tr>
                                            <tr><td style="padding: 6px 6px;">Country : 
                                                    <?php
                                                     $countryArray = explode(',', $offer['country_id']);
                                                     $getcountry = $this->LandingModel->getcountryinfo($countryArray);
                                                     $coun = '';
                                                     foreach ($getcountry as $ccc) {
                                                        $coun[] = $ccc['country_name'];
                                                    }
                                                     echo implode(", ", $coun);
                                                    ?>
                                                </td></tr>
                                            <tr><td style="padding: 6px 6px;">Tag : 
                                                    <?php 
                                                    if(isset($offer['keyword'])) {
                                                    $keyArray = explode(',', $offer['keyword']);
                                                    $getkeyword = $this->LandingModel->getkeywordinfo($keyArray);
                                                    $k = '';
                                                    foreach ($getkeyword as $kkk) {
                                                        $k[] = $kkk['keyword_tags'];
                                                    }
                                                     $tags = implode(", ", $k);
                                                     if (isset($tags)) {
                                                        echo $tags;
                                                     }
                                                     }
                                                    ?></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!--                                     </div>-->
                        <?php
                    }
                } else {
                    ?>
                </div>
                <div>
                    <h3 style="color:red">There is no data according your criteria !!!!</h3>
                </div>
            <?php } ?>
        </div>
        <div class="clearfix"></div>
</div>