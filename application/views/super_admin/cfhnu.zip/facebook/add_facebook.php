<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <!--                    <h5 style="color: red;"><?php
                    if (validation_errors()) {
                        echo validation_errors();
                    }
                    ?>
                                        </h5>-->
                    <form action="admin/saveFacebookAds" method="post" enctype="multipart/form-data">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label">Type<span style="color:red">*</span></label>
                                <div class="radio-list">

                                    <label class="radio-inline p-0">
                                        <div class="radio radio-info">
                                            <input type="radio" name="type" id="radio1" value="1" <?php echo set_radio('gender', '1'); ?> onclick="showDiv(this)">
                                            <label for="radio1">Embedded Code</label>
                                        </div>
                                    </label>

                                    <label class="radio-inline">
                                        <div class="radio radio-info">
                                            <input type="radio" name="type" id="radio2" value="2" <?php echo set_radio('gender', '2'); ?> onclick="showDiv(this)">
                                            <label for="radio2">Manually Entry</label>
                                        </div>
                                    </label>

                                </div>
                            </div>
                        </div>


                        <div id="code" style="display: none;">
                            <div class="form-group">
                                <label for="exampleInputuname">Embedded Code<span style="color:red">*</span></label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Embedded Code">
                            </div>
                        </div>


                        <div id="manual" style="display: none;">
                            <div class="form-group">
                                <label for="exampleInputuname">Fan Page Name</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Embedded Code">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Add Text</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Add Text">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Headline</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Headline">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Description</label>
                                <textarea class="form-control" name="address" style="resize: none"><?php echo set_value('address'); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputuname">Facebook Type</label>
                                <div class="radio-list">

                                    <label class="radio-inline p-0">
                                        <div class="radio radio-info">
                                            <input type="radio" name="type" id="radio1" value="1" <?php echo set_radio('gender', '1'); ?> onclick="showDiv(this)">
                                            <label for="radio1">News Feed</label>
                                        </div>
                                    </label>

                                    <label class="radio-inline">
                                        <div class="radio radio-info">
                                            <input type="radio" name="type" id="radio2" value="2" <?php echo set_radio('gender', '2'); ?> onclick="showDiv(this)">
                                            <label for="radio2">Right Side Ad</label>
                                        </div>
                                    </label>

                                </div>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Fan page URL</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Fan page URL">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Landing page URL</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Landing page URL">
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Logo<span style="color:red">*</span></label>
                                <input type="file" name="slider_image" value="<?php echo set_value('slider_image'); ?>" id="input-file-now" class="dropify"/>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputuname">Categories(For Bulk)</label>
                                <select class="select2 m-b-10 select2-multiple" multiple="multiple" name="hobbies[]">
                                    <option value="0">Choose Categories</option>
                                    <option value="1">Category 1</option>
                                    <option value="2">Category 2</option>
                                    <option value="3">Category 3</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Countries(For Bulk)</label>
                                <select class="select2 m-b-10 select2-multiple" multiple="multiple" name="hobbies[]">
                                    <option value="0">Choose Countries</option>
                                    <?php foreach ($all_country as $country) { ?>
                                        <option value="<?php echo $country['country_id'] ?>"><?php echo $country['country_name'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputuname">Keywords(For Bulk)</label>
                                <input type="text" name="membership_price" class="form-control" value="<?php echo set_value('membership_price'); ?>" placeholder="Keywords">
                            </div>

                            <div class="dropzone" id="myId">
                                
                            </div>
                            <div class="previews" id="preview"></div>
                            
                            
                        </div>


                        <button type="submit" id="myBtn" class="btn btn-success waves-effect waves-light m-r-10">Submit</button>
                        <!--<button type="submit" class="btn btn-inverse waves-effect waves-light">Cancel</button>-->
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>


<script>


    function showDiv(val) {
        var type = val.value;
//        alert(type);
        if (type == 1) {
            document.getElementById('code').style.display = "block";
            document.getElementById('manual').style.display = "none";
        }
        if (type == 2) {
            document.getElementById('manual').style.display = "block";
            document.getElementById('code').style.display = "none";
        }
    }
</script>



<script>
    $(function() {
    Dropzone.options.myId = {
        acceptedFiles: "image/*",
        addRemoveLinks: true,
        previewsContainer: ".previews",
        url:"admin/saveFacebookAds",
    init: function() {
      
        thisDropzone = this;
        this.on(
            "addedfile", function(file) {
              caption = file.caption == undefined ? "" : file.caption;
              file._captionLabel = Dropzone.createElement("<label for='exampleInputuname'>Categories</label>")
              file._captionBox = Dropzone.createElement(
                      "<select id='"+file.filename+"' class='select2 m-b-10 select2-multiple' multiple='multiple' name='catgory[]' value="+caption+">\n\
                                <option value='0'>Choose Category</option>\n\
                                <option value='1'>Category 1</option>\n\
                                <option value='2'>Category 2</option>\n\
                                <option value='3'>Category 3</option>\n\
                                                    </select>");
              file.previewElement.appendChild(file._captionLabel);
              file.previewElement.appendChild(file._captionBox);
              
              select = file.select == undefined ? "" : file.select;
              file._selectLabel = Dropzone.createElement("<label for='exampleInputuname'>Countries</label>")
              file._selectBox = Dropzone.createElement(
                      "<select id='"+file.filename+"' class='select2 m-b-10 select2-multiple' multiple='multiple' name='country[]' value="+caption+">\n\
                                <option value='0'>Choose Country</option>\n\
                                <?php foreach ($all_country as $country){?>\n\
                                <option value='<?php echo $country['country_id']?>'><?php echo $country['country_name']?></option>\n\\n\
                                <?php }?>\n\
                                                    </select>");
              file.previewElement.appendChild(file._selectLabel);
              file.previewElement.appendChild(file._selectBox);
              
              keyword = file.select == undefined ? "" : file.select;
              file._keywordLabel = Dropzone.createElement("<label for='exampleInputuname'>Keyword</label>")
              file._keywordBox = Dropzone.createElement(
                      "<input id='"+file.filename+"' type='text' name='email' class='form-control'>");
              file.previewElement.appendChild(file._keywordLabel);
              file.previewElement.appendChild(file._keywordBox);
              $("select").select2();
              
//                 if (errorMessage.indexOf('Error 404') !== -1) {
//                    var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
//                    errorDisplay[errorDisplay.length - 1].innerHTML = 'Error 404: The upload page was not found on the server';
//                  }
        }),
        this.on(
            "sending", function(file, xhr, formData){
            formData.append('yourPostName',file._captionBox.value);
        })
    }
};
});
    
</script>
