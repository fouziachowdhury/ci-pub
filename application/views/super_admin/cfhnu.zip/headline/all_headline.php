<div class="row">
    <div class="col-sm-12">
        <div class="white-box">
            <a>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal">
                    Add Headline
                </button>
            </a>
            
            
            <!-- Modal -->
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel">Add Headline</h4>
                        </div>
                        <form action="admin/saveHeadline" name="myForm" onsubmit="return validateForm()" method="post" enctype="multipart/form-data">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label class="control-label">Type<span style="color:red">*</span></label>
                                    <div class="radio-list">
                                        <label class="radio-inline p-0">
                                            <div class="radio radio-info">
                                                <input type="radio" name="type" id="radio1" value="1" <?php echo set_radio('gender', '1'); ?> onclick="showDiv(this)">
                                                <label for="radio1">Category Type</label>
                                            </div>
                                        </label>

                                        <label class="radio-inline">
                                            <div class="radio radio-info">
                                                <input type="radio" name="type" id="radio2" value="2" <?php echo set_radio('gender', '2'); ?> onclick="showDiv(this)">
                                                <label for="radio2">Country Type</label>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="form-group" id="category" style="display: none;">
                                    <label class="control-label">Category</label>
                                    <select class="form-control select2" name="category" onchange="showMyModel(this.value)">
                                        <option value="0">Choose</option>
                                        <?php foreach ($all_category as $cat){?>
                                        <option value="<?php echo $cat['cat_id'];?>"><?php echo $cat['cat_name'];?></option>
                                        <?php }?>
                                    </select>
                                </div>
                                
                                <div class="form-group" id="country" style="display: none;">
                                    <label class="control-label">Country</label>
                                    <select class="form-control select2" name="country" onchange="showMyModel(this.value)">
                                        <option value="0">Choose Country</option>
                                        <?php foreach ($all_country as $country) { ?>
                                            <option value="<?php echo $country['country_id'] ?>"><?php echo $country['country_name'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputuname">Headline Name</label>
                                    <input type="text" name="headline" class="form-control" id="exampleInputuname" placeholder="Headline Name">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            
            <!--Modal End-->
            <h3 class="" style="text-align: center;">All Headline</h3>
            <div class="table-responsive">
                <ul class="list-unstyled list-inline" style="text-align: right;">
                    
                </ul>
                <table id="myTable" class="table table-striped">
                    <thead>
                
                        <!--<p style="text-align: right;color: red;">Search By Name, Email, Fee Paid</p>-->
                        <tr>
                            <th style="text-align: center;">Sl No.</th>
                            <th style="text-align: center;">Headline</th>
                            <th style="text-align: center;">Type</th>
                            <th style="text-align: center;">Status</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr style="text-align: center;">
                            <td>
                                1
                            </td>
                            <td>Headline</td>
                            <td>Category 2</td>
                            <td>
                                <label class="label label-success" style="line-height: 2">Active</label>
                            </td>
                            <td>
                                <a href="super_admin/change_type/">
                                    <span data-toggle="tooltip" data-placement="top" title="Change Status" class="glyphicon glyphicon-refresh"></span>
                                </a>&nbsp;
                                <a data-toggle="modal" data-target="#editLink" style="cursor: pointer;">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Headline" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
<!--                                <a href="super_admin/editBannerImage/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner Image" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;-->
                                <a href="super_admin/delete_user/" onclick="return chkDelete()">
                                    <span data-toggle="tooltip" data-placement="top" title="Remove" class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                        </tr>
                        
                        <tr style="text-align: center;">
                            <td>
                                2
                            </td>
                            <td>Headline 2</td>
                            <td>Country</td>
                            <td>
                                <label class="label label-danger" style="line-height: 2">Inactive</label>
                            </td>
                            <td>
                                <a href="super_admin/change_type/">
                                    <span data-toggle="tooltip" data-placement="top" title="Change Status" class="glyphicon glyphicon-refresh"></span>
                                </a>&nbsp;
                                <a data-toggle="modal" data-target="#editLink" style="cursor: pointer;">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Headline" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
<!--                                <a href="super_admin/editBannerImage/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner Image" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;-->
                                <a href="super_admin/delete_user/" onclick="return chkDelete()">
                                    <span data-toggle="tooltip" data-placement="top" title="Remove" class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                            
                            <div id="editLink" class="modal fade" role="dialog">
                                <div class="modal-dialog">
                                    <!-- Modal content-->
                                        
                                    <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close"
                                                        data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title" style="text-align: center">Edit Headline</h4>
                                            </div>
                                        <form action="super_admin/updateHobby" method="post" enctype="multipart/form-data">
                                                <input type="hidden" name="hobby_id" class="form-control" value="">
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="form-group">
                                                            <label class="control-label">Type<span style="color:red">*</span></label>
                                                            <div class="radio-list">
                                                                <label class="radio-inline p-0">
                                                                    <div class="radio radio-info">
                                                                        <input type="radio" name="type" id="radio" checked="" value="1" <?php echo set_radio('gender', '1'); ?> onclick="showDiv(this)">
                                                                        <label for="radio">Category Type</label>
                                                                    </div>
                                                                </label>

                                                                <label class="radio-inline">
                                                                    <div class="radio radio-info">
                                                                        <input type="radio" name="type" id="radio3" value="2" <?php echo set_radio('gender', '2'); ?> onclick="showDiv(this)">
                                                                        <label for="radio3">Country Type</label>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group" id="category" style="display: block;">
                                                            <label class="control-label">Category</label>
                                                            <select class="form-control select2" name="about_site" onchange="showMyModel(this.value)">
                                                                <option value="0">Choose</option>
                                                                <option value="1">Category 1</option>
                                                                <option value="2">Category 2</option>
                                                                <option value="3">Category 3</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group" id="country" style="display: none;">
                                                            <label class="control-label">Country</label>
                                                            <select class="form-control select2" name="about_site" onchange="showMyModel(this.value)">
                                                                <option value="0">Choose Country</option>
                                                                <?php foreach ($all_country as $country) { ?>
                                                                    <option value="<?php echo $country['country_id'] ?>"><?php echo $country['country_name'] ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label for="form-first-name">Headline Name</label>
                                                            <input type="text" name="hobby_name" class="form-control" value="">
                            <!--                            <span class="help-inline">Mensagem de erro do campo</span> -->
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                    <button type="submit" id="sub_button" class="btn btn-success">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                </div>
                            </div>
                            
                        </tr>

                    </tbody>
                </table>
                
                
                <div class="modal fade" id="quick_view_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

                </div>
                
                
            </div>
        </div>
    </div>
</div>

<script>
    
    function showDiv(val) {
        var type = val.value;
//        alert(type);
        if (type == 1) {
            document.getElementById('category').style.display = "block";
            document.getElementById('country').style.display = "none";
        }
        if (type == 2) {
            document.getElementById('country').style.display = "block";
            document.getElementById('category').style.display = "none";
        }
    }
    
</script>

<script>
    $(document).ready(function (){
        $("#active").prop("checked", true);
        $("#inactive").prop("checked", true);
        $("#trial").prop("checked", true);
        
    });
     
</script>

<script>
    function chkDelete(){
        var chk = confirm("Are You Sure to Delete This ?");
        if(chk){
            return true;
        }
        else{
            return false;
        }
    }
</script>

<script type="text/javascript">

    function view_user(reg_id) {
//        alert(reg_id);
        $.ajax({
            url: "<?php echo site_url('super_admin/viewUserModal'); ?>",
            type: "post",
            data: {reg_id: reg_id},
            success: function (msg) {
//                alert("" + msg);
                $('#quick_view_modal').html(msg);
                $('#quick_view_modal').modal('show');
            }
        });
    }
</script>