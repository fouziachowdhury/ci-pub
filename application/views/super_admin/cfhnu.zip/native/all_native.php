<div class="row">
    <div class="col-sm-12">
        <div class="white-box">
            <h3 class="" style="text-align: center;">All Native Ads</h3>
            <div class="table-responsive">
                <ul class="list-unstyled list-inline" style="text-align: right;">
<!--                    <li><h4>Filter By</h4></li>
                    <li>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Category
                                <span class="fa fa-sort-desc"></span></button>
                            <ul class="dropdown-menu dropdown-design">
                                <li><a href="#">A</a></li>
                                <li><a href="#">B</a></li>
                                <li><a href="#">C</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Country
                                <span class="fa fa-sort-desc"></span></button>
                            <ul class="dropdown-menu dropdown-design">
                                <li><a href="#">A</a></li>
                                <li><a href="#">B</a></li>
                                <li><a href="#">C</a></li>
                            </ul>
                        </div>
                    </li>-->
                </ul>
                <form action="admin/editMultipleNative" method="post">
                <table id="myTable" class="table table-striped">
                    <thead>
                        <!--<p style="text-align: right;color: red;">Search By Name, Email, Fee Paid</p>-->
                        <tr>
                        <a href="editMultipleBanner" style="display: none;margin: 5px 0px;" id="editButton">
                            <button type="submit" class="btn btn-info">Edit</button>
                        </a>
                            <th style="text-align: center;"></th>
                            <th style="text-align: center;">Image</th>
                            <th style="text-align: center;">Size</th>
                            <th style="text-align: center;">Category</th>
                            <th style="text-align: center;">Country</th>
                            <th style="text-align: center;">Date</th>
                            <th style="text-align: center;">Status</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <tr style="text-align: center;">
                            <td>
                                <input id="check_id" name="banner_id[]" type="checkbox" value="1" onclick="showButton()">
                            </td>
                            <td>
                                <img src="assets/admin/images/assets/landscape1.jpg" alt="Banner Image" style="width: 100px;">
                            </td>
                            <td>250 * 150</td>
                            <td>Category</td>
                            <td>Bangladesh</td>
                            <td>15 April, 2017</td>
                            <td>
                                <label class="label label-success" style="line-height: 2">Active</label>
                            </td>
                            <td>
                                <a href="super_admin/change_type/">
                                    <span data-toggle="tooltip" data-placement="top" title="Change Status" class="glyphicon glyphicon-refresh"></span>
                                </a>&nbsp;
                                <a href="admin/editNativeBanner/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
<!--                                <a href="super_admin/editBannerImage/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner Image" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;-->
                                <a href="super_admin/delete_user/" onclick="return chkDelete()">
                                    <span data-toggle="tooltip" data-placement="top" title="Remove" class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                        </tr>
                        
                        <tr style="text-align: center;">
                            <td>
                                <input id="checkbox0" type="checkbox">
                            </td>
                            <td>
                                <img src="assets/admin/images/assets/background.png" alt="Banner Image" style="width: 100px;">
                            </td>
                            <td>200 * 100</td>
                            <td>Fee Paid</td>
                            <td>India</td>
                            <td>17 April, 2017</td>
                            <td>
                                <label class="label label-danger" style="line-height: 2">Inactive</label>
                            </td>
                            <td>
                                <a href="super_admin/change_type/">
                                    <span data-toggle="tooltip" data-placement="top" title="Change Status" class="glyphicon glyphicon-refresh"></span>
                                </a>&nbsp;
                                <a href="super_admin/editBanner/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
<!--                                <a href="super_admin/editBannerImage/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Banner Image" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;-->
                                <a href="super_admin/delete_user/" onclick="return chkDelete()">
                                    <span data-toggle="tooltip" data-placement="top" title="Remove" class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                        </tr>
                        
                       
                        

                    </tbody>
                </table>
                </form>
                
                <div class="modal fade" id="quick_view_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

                </div>
                
                
            </div>
        </div>
    </div>
</div>

<script>
//    $('#check_id').click(function() {
//    "Checkbox state (method 1) = " + $('#check_id').prop('checked');
//    if("Checkbox state (method 1) = " + $('#check_id').prop('checked') == true){
//        document.getElementById('editButton').style.display = "block";
//    }
//    else{
//        document.getElementById('editButton').style.display = "none";
//    }
//});
    function showButton(){
//        var chkValue = $('#check_id').val();
//        alert(chkValue);
        if ($('#check_id').is(":checked")){
            document.getElementById('editButton').style.display = "block";
        }
        else{
            document.getElementById('editButton').style.display = "none";
        }
        
    }
    
</script>

<script>
    $(document).ready(function (){
        $("#active").prop("checked", true);
        $("#inactive").prop("checked", true);
        $("#trial").prop("checked", true);
        
    });
     
</script>

<script>
    function chkDelete(){
        var chk = confirm("Are You Sure to Delete This ?");
        if(chk){
            return true;
        }
        else{
            return false;
        }
    }
</script>
