<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            <!--<h3 class="box-title m-b-0">Add Native Ads </h3>-->
            <!--<p class="text-muted m-b-30"> For multiple file upload</p>-->
            <form action="admin/saveNativeAds" method="post" enctype="multipart/form-data">
                
                <div class="form-group" id="">
                    <label for="exampleInputuname">Categories(For Bulk)</label>
                    <select class="select2 m-b-10" multiple="multiple" name="hobbies[]" id="bulk_category" onchange="bulkCategory()">
                        <option value="0">Choose Headline</option>
                        <option value="1">Category 1</option>
                        <option value="2">Category 2</option>
                        <option value="3">Category 3</option>
                    </select>
                </div>
                
                <div class="form-group" id="">
                    <label for="exampleInputuname">Headline(For Bulk)</label>
                    <select class="select2 m-b-10" multiple="multiple" id="headline" name="hobbies[]">
<!--                        <option value="0">Choose Headline</option>
                        <option value="1">Headline 1</option>
                        <option value="2">Headline 2</option>
                        <option value="3">Headline 3</option>-->
                    </select>
                </div>
                
                <div class="dropzone" id="myDropzone" name="file">
                    <!--<input name="file" type="file" multiple />-->      
                </div>
<!--                <div class="fallback">
                    <input name="file" type="file" multiple />
                </div>-->
                
                <div class="previews" id="preview"></div>
<!--                <div class="form-group" id="headline" style="display: none;">
                    <label for="exampleInputuname">Headline</label>
                    <select class="select2 m-b-10" multiple="multiple" name="hobbies[]">
                        <option value="0">Choose Headline</option>
                        <option value="1">Headline 1</option>
                        <option value="2">Headline 2</option>
                        <option value="3">Headline 3</option>
                    </select>
                </div>-->
                <button type="submit" class="btn btn-success">Submit</button>
            </form>
            
        </div>
    </div>
</div>



<script>
    $(function() {
Dropzone.options.myDropzone = {
        
    url:"admin/saveNativeAds",
    acceptedFiles: "image/*",
    autoProcessQueue: false,
    addRemoveLinks: true,
    previewsContainer: ".previews",
//    method: "post",
  init: function() {
      var count = 0;
        thisDropzone = this;
        this.on("addedfile", function(file) {
              caption = file.caption == undefined ? "" : file.caption;
              file._captionLabel = Dropzone.createElement("<label for='exampleInputuname'>Categories</label>")
              file._captionBox = Dropzone.createElement(
                      "<select id='catgory"+count+"' class='select2 m-b-10 select2-multiple' multiple='multiple' name='catgory[]' onchange='getCategory("+count+")'>\n\
                                <option value='0'>Choose Category</option>\n\
                                <option value='1'>Category 1</option>\n\
                                <option value='2'>Category 2</option>\n\
                                <option value='3'>Category 3</option>\n\
                        </select>");
              file.previewElement.appendChild(file._captionLabel);
              file.previewElement.appendChild(file._captionBox);
              
              headline = file.headline == undefined ? "" : file.headline;
              file._headlineLabel = Dropzone.createElement("<label for='exampleInputuname'>Headline</label>")
              file._headlineBox = Dropzone.createElement(
                      "<select id='heading"+count+"' class='headline' multiple='multiple' name='country[]'>\n\
                        </select>");
              file.previewElement.appendChild(file._headlineLabel);
              file.previewElement.appendChild(file._headlineBox);
              
              select = file.select == undefined ? "" : file.select;
              file._selectLabel = Dropzone.createElement("<label for='exampleInputuname'>Countries</label>")
              file._selectBox = Dropzone.createElement(
                      "<select id='"+file.filename+"' class='select2 m-b-10 select2-multiple' multiple='multiple' name='country[]'>\n\
                                <option value='0'>Choose Country</option>\n\
                                   <?php foreach ($all_country as $country){?>\n\
                                <option value='<?php echo $country['country_id']?>'><?php echo $country['country_name']?></option>\n\
                                   <?php }?>\n\
                        </select>");
              file.previewElement.appendChild(file._selectLabel);
              file.previewElement.appendChild(file._selectBox);
              
              keyword = file.select == undefined ? "" : file.select;
              file._keywordLabel = Dropzone.createElement("<label for='exampleInputuname'>Keyword</label>")
              file._keywordBox = Dropzone.createElement(
                      "<input id='Keyword"+count+"' type='text' name='keyword' class='form-control'>");
              file.previewElement.appendChild(file._keywordLabel);
              file.previewElement.appendChild(file._keywordBox);
              $("select").select2();
              count++;
        }),
        this.on(
            "sending", function(file, xhr, formData){
            formData.append('yourPostName',file._captionBox.value);
        });
        
        
        
    }
};
});
    
</script>

<script>
    
    function getCategory(count){
        var cat_id = $(".select2-multiple").val();
//        alert(count);
        $.ajax({
            url: "admin/select_headline",
            type: "post",
            data: {cat_id:cat_id},
            success: function(msg) {
//                            alert(msg);
                $('#heading'+count).html(msg);
                $("select").select2();
            }

        });
//        $("#headline").show();
    }
</script>


<script>
    
    function bulkCategory(){
        var cat = $("#bulk_category").val();
//        alert(cat);
        $.ajax({
            url: "admin/select_headline",
            type: "post",
            data: {cat_id:cat},
            success: function(msg) {
                            alert(msg);
                $('#headline').html(msg);
            }

        });
    }
    
</script>