<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
<!--                    <h5 style="color: red;"><?php if (validation_errors()) {
                                                    echo validation_errors();
                                            } ?>
                    </h5>-->
                    <form action="super_admin/save_user" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="exampleInputuname">First Name<span style="color:red">*</span></label>
                            <input type="text" name="first_name" class="form-control" value="<?php echo set_value('first_name'); ?>" placeholder="First Name">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputuname">Last Name<span style="color:red">*</span></label>
                            <input type="text" name="last_name" class="form-control" value="<?php echo set_value('last_name'); ?>" placeholder="Last Name">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputuname">User Name<span style="color:red">*</span></label>
                            <input type="text" name="user_name" class="form-control" value="<?php echo set_value('user_name'); ?>" placeholder="User Name" onkeyup="chkUser(this)">
                            <span id="chk_user_msg" style="display: none;color: red;">This User Name Exist</span>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputuname">User's Company Name</label>
                            <input type="text" name="company_name" class="form-control" value="<?php echo set_value('company_name'); ?>" placeholder="Company Name">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputuname">Email<span style="color:red">*</span></label>
                            <input type="text" name="email" class="form-control" value="<?php echo set_value('email'); ?>" placeholder="Email Address" onkeyup="chkEmail(this);chkValidEmail(this);">
                            <span id="chk_email_msg" style="display: none;color: red;">This Email Exist</span>
                            <span id="valid_email_msg" style="display: none;color: red;">Please use only letters (a-z), numbers, and periods.</span>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputuname">Mobile<span style="color:red">*</span></label>
                            <input type="text" name="mobile" class="form-control" value="<?php echo set_value('mobile'); ?>" placeholder="Mobile Number" onkeyup="chkValidMobile(this)">
                            <span id="valid_mobile_msg" style="display: none;color: red;">This Input Field Contain Only Numbers</span>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label">Gender<span style="color:red">*</span></label>
                                <div class="radio-list">
                                    <label class="radio-inline p-0">
                                        <div class="radio radio-info">
                                            <input type="radio" name="gender" id="radio1" value="1" <?php echo set_radio('gender', '1'); ?>>
                                            <label for="radio1">Male</label>
                                        </div>
                                    </label>
                                    <label class="radio-inline">
                                        <div class="radio radio-info">
                                            <input type="radio" name="gender" id="radio2" value="2" <?php echo set_radio('gender', '2'); ?>>
                                            <label for="radio2">Female</label>
                                        </div>
                                    </label>
                                    <label class="radio-inline">
                                        <div class="radio radio-info">
                                            <input type="radio" name="gender" id="radio3" value="3" <?php echo set_radio('gender', '3'); ?>>
                                            <label for="radio3">Others</label>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>

<!--                        <div class="form-group">
                            <label class="control-label">Type</label>
                            <select class="form-control select2" name="type">
                                <option value="0">Choose User Type</option>
                                <option value="2">Owner</option>
                                <option value="3">User</option>
                            </select>
                        </div>-->

                        <div class="form-group">
                            <label for="exampleInputuname">Date Of Birth</label>
                            <input type="text" name="dob" class="form-control datepicker-inline" value="<?php echo set_value('dob'); ?>" placeholder="yyyy/mm/dd">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputuname">Address</label>
                            <textarea class="form-control" name="address" style="resize: none"><?php echo set_value('address'); ?></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label col-md-12">Type<span style="color:red">*</span></label>
                                <div class="col-sm-4">
                                    <div class="checkbox checkbox-success">
                                        <input type="checkbox" name="trusted_facility" id="facility_check" onclick="showDiv()" value="0" <?php echo set_checkbox('trusted_facility', '0'); ?> >
                                        <label for="facility_check">Trusted Facility</label>
                                    </div>

                                </div>
                                <div class="col-sm-4">
                                    <div class="checkbox checkbox-success">
                                        <input type="checkbox" name="trusted_user" checked="" id="user_check" onclick="showDiv()" value="1" <?php echo set_checkbox('trusted_user', '1');?>>
                                        <label for="user_check">Trusted User</label>
                                    </div>

                                </div>
                            </div>
                            
                        </div>

                        <?php if($all_facility != NULL || set_checkbox('trusted_facility', '0')){ ?>
                            <div id="showFacility" style="display: none">
                                <label for="exampleInputuname">Select Facility</label>
                                <select class="select2 m-b-10 select2-multiple" multiple="multiple" name="facility_id[]">
                                    <option value="0">Choose Facility</option>
                                    <?php foreach ($all_facility as $facility){?>
                                    <option value="<?php echo $facility->facility_id;?>" <?php echo set_select('facility_id',  $facility->facility_id); ?>>
                                        <?php echo $facility->facility_title;?>
                                    </option>
                                    <?php }?>
                                </select>
                            </div>
                        <?php } ?>

                        <div class="form-group">
                            <label for="exampleInputuname">Interested Activities</label>
                            <select class="select2 m-b-10 select2-multiple" multiple="multiple" name="intersted_activities[]" id="activities" onchange="getActivities()">
                                <option value="0">Choose Activities</option>
                                <option value="1" <?php echo set_select('intersted_activities', '1'); ?> >Activities 1</option>
                                <option value="2" <?php echo set_select('intersted_activities', '2'); ?>>Activities 2</option>
                                <!--<option value="Add">Add Activities</option>-->
                            </select>
                            <!--<input type="text" name="intersted_activities" class="form-control" value="<?php echo set_value('intersted_activities'); ?>"  placeholder="Interested Activities">-->
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputuname">Hobbies</label>
                            <select class="select2 m-b-10 select2-multiple" multiple="multiple" name="hobbies[]" onchange="showHobbiesModel(this.value)">
                                <option value="0">Choose Activities</option>
                                <?php foreach ($all_hobby as $hobby){?>
                                    <option value="<?=$hobby->hobby_id?>" <?php echo set_select('hobbies', $hobby->hobby_id); ?>>
                                    <?=$hobby->hobby_name?>
                                    </option>>
                                <?php }?>
                                <!--<option value="add_hobbies">Add Hobbies</option>-->
                            </select>
                            <!--<input type="text" name="intersted_activities" class="form-control" value="<?php echo set_value('intersted_activities'); ?>"  placeholder="Interested Activities">-->
                        </div>
                        
                        <div class="form-group">
                            <label class="control-label">How Know About The Site</label>
                            <select class="form-control select2" name="about_site" onchange="showMyModel(this.value)">
                                <option value="0">Choose</option>
                                <?php foreach ($all_about_site as $about_site){?>
                                    <option value="<?=$about_site->about_site_id?>" <?php echo set_select('about_site', $about_site->about_site_id); ?>>
                                    <?=$about_site->about_site?>
                                    </option>>
                                <?php }?>
                            </select>
                        </div>

                        <button type="submit" id="myBtn" class="btn btn-success waves-effect waves-light m-r-10">Submit</button>
                        <!--<button type="submit" class="btn btn-inverse waves-effect waves-light">Cancel</button>-->
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--    <div class="col-sm-12 ol-md-12 col-xs-12">
            <div class="white-box">
                <h3 class="box-title">File Upload1</h3>
                <label for="input-file-now">Image</label>
                
            </div>
        </div>-->
    
    
    
    
</div>

<script>
    
    
    function showDiv(){
        var type = $("input[name=trusted_facility]:checked").val();
//        var facility = document.getElementById('facility_check').value;
//        var user = document.getElementById('user_check').value;
//        alert(type);
        if(type == 0){
            document.getElementById('showFacility').style.display = "block";
        }
        else{
            document.getElementById('showFacility').style.display = "none";
        }
    }
</script>


<script>
    
    function chkUser(user){
        var user_name = user.value;
        
        $.ajax({
            type: 'POST',
           url: "super_admin/check_user_name",
           data: {user_name : user_name},
           success: function (data) {
               if(data == 0){
                   document.getElementById('chk_user_msg').style.display = "block";
                   $(":submit").attr("disabled", true);
               }
              if(data == 1){
                   document.getElementById('chk_user_msg').style.display = "none";
                   $(":submit").removeAttr("disabled");
               }
           }
           
        });
    }
    
    function chkEmail(email){
        var email_address = email.value;
//        alert(email_address);
        $.ajax({
            type: 'POST',
           url: "super_admin/check_email",
           data: {email : email_address},
           success: function (data) {
               if(data == 0){
                   document.getElementById('chk_email_msg').style.display = "block";
                   $(":submit").attr("disabled", true);
               }
               else{
                   document.getElementById('chk_email_msg').style.display = "none";
                   $(":submit").removeAttr("disabled");
               }
           }
           
        });
    }
    
    function chkValidEmail(email){
        var email_add = email.value;
        var filter = /^([a-z0-9_\.\-])+([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
//        alert(email_add);

        if (!filter.test(email_add)){
            document.getElementById('valid_email_msg').style.display = 'block';
            $(":submit").attr("disabled", true);
        }
        else{
            document.getElementById('valid_email_msg').style.display = 'none';
            $(":submit").removeAttr("disabled");
        }
        
    }
    
    function chkValidMobile(mobile){
        var mobile_no = mobile.value;
//        alert(mobile_no);
        if (isNaN(mobile_no)){
                document.getElementById('valid_mobile_msg').style.display = 'block';
                $(":submit").attr("disabled", true);
            }
            else{
                $(":submit").removeAttr("disabled");
            }
    }
    
</script>

<script type="text/javascript">
    
    function getActivities() {
        var value = $( "#activities option:selected").val();
        if(value == 'Add'){
//          $('#activities option').attr('disabled',true);
            $('#modal-content').modal({
            show: true
        });
        } 
    }
    
    function showMyModel(val)
    {
        if (val == "add") {
            $('#modal-site').modal({
                show: true
            });
        }
    }
    
    function showHobbiesModel(val)
    {
        if (val == "add_hobbies") {
            $('#modal-hobbies').modal({
                show: true
            });
        }
    }
        
        
    

</script>
