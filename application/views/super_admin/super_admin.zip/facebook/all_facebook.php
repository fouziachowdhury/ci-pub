<div class="row">
    <div class="col-sm-12">
        <div class="white-box">
            <h3 class="" style="text-align: center;">All Facebook Ads</h3>
            <div class="table-responsive">
                <ul class="list-unstyled list-inline" style="text-align: right;">
                    <!--<li><h4>Filter By</h4></li>-->
<!--                    <li><button class="btn btn-success">Newest</button></li>
                    <li><button class="btn btn-success">Oldest</button></li>
                    <li><button class="btn btn-success">Size</button></li>-->
<!--                    <li>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Category
                                <span class="fa fa-sort-desc"></span></button>
                            <ul class="dropdown-menu dropdown-design">
                                <li><a href="#">A</a></li>
                                <li><a href="#">B</a></li>
                                <li><a href="#">C</a></li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Country
                                <span class="fa fa-sort-desc"></span></button>
                            <ul class="dropdown-menu dropdown-design">
                                <li><a href="#">A</a></li>
                                <li><a href="#">B</a></li>
                                <li><a href="#">C</a></li>
                            </ul>
                        </div>
                    </li>-->
                </ul>
                <form action="admin/editMultipleFacebook" method="post">
                <ul class="list-inline list-unstyled">
                        <li>
                            <a style="display: none;margin: 5px 0px;" id="editButton">
                                <button type="submit" name="edit" class="btn btn-info">Edit</button>
                            </a>
                        </li>
                        <li>
                            <a style="display: none;margin: 5px 0px;" id="deleteButton" onclick="return chkDelete()">
                                <button type="submit" name="delete" class="btn btn-danger">Delete</button>
                            </a> 
                        </li>
                    </ul>
                <table id="myTable" class="table table-striped">
                    
                    <thead>
                
                        <!--<p style="text-align: right;color: red;">Search By Name, Email, Fee Paid</p>-->
                        
                        <tr>
                            <th style="text-align: center;">Sl No.</th>
                            <th style="text-align: center;">Image</th>
                            <th style="text-align: center;">Size</th>
                            <th style="text-align: center;">Category</th>
                            <th style="text-align: center;">Country</th>
                            <th style="text-align: center;">Date</th>
                            <th style="text-align: center;">Status</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; foreach ($all_facebook_ads as $row){?>
                        <tr style="text-align: center;">
                            <td>
                                <input class="check_id" name="fb_images_id[]" type="checkbox" value="<?php echo $row['fb_images_id'];?>" onclick="showButton()">
                            </td>
                            <td>
                                <img src="uploads/facebook_ads/<?php echo $row['image']?>" alt="Banner Image" style="width: 100px;">
                            </td>
                            <td><?php echo $row['width']?> * <?php echo $row['height']?></td>
                            <td>
                                <?php $category = explode(',', $row['cat_id']);
//                                    print_r($category);
                                foreach ($category as $cat){
                                foreach ($all_category as $all_cat){
                                    if($all_cat['cat_id'] == $cat){
                                        echo $all_cat['cat_name'].'<br>';
                                    }
                                }}?>
                            </td>
                            <td>
                                <?php $country = explode(',', $row['country_id']);
//                                    print_r($category);
                                foreach ($country as $cnt){
                                foreach ($all_country as $country){
                                    if($country['country_id'] == $cnt){
                                        echo $country['country_name'].'<br>';
                                    }
                                }}?>
                            </td>
                            <td><?php echo $row['date'];?></td>
                            <td>
                                <label class="label label-success" style="line-height: 2">Active</label>
                            </td>
                            <td>
                                <a href="super_admin/change_type/">
                                    <span data-toggle="tooltip" data-placement="top" title="Change Status" class="glyphicon glyphicon-refresh"></span>
                                </a>&nbsp;
                                <a href="admin/editFacebook/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Facebook Ads" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
                                <a href="admin/editFcaebookImage/">
                                    <span data-toggle="tooltip" data-placement="top" title="Edit Facebook Image" class="glyphicon glyphicon-edit"></span>
                                </a>&nbsp;
                                <a href="super_admin/delete_user/" onclick="return chkDelete()">
                                    <span data-toggle="tooltip" data-placement="top" title="Remove" class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                        </tr>
                        <?php $i++;}?> 

                    </tbody>
                </table>

                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function showButton(){
        if ($('.check_id').is(":checked")){
            document.getElementById('editButton').style.display = "block";
            document.getElementById('deleteButton').style.display = "block";
        }
        else{
            document.getElementById('editButton').style.display = "none";
            document.getElementById('deleteButton').style.display = "none";
        }
    }
    
</script>

<script>
    function chkDelete(){
        var chk = confirm("Are You Sure to Delete This ?");
        if(chk){
            return true;
        }
        else{
            return false;
        }
    }
</script>