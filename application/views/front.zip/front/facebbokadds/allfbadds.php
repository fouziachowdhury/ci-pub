<?php if (isset($permission_message)) { ?>
    <h1><?php echo $permission_message; ?></h1>
<?php } else { ?>
    <div class="row">
        <div id="all_time" style="display: block;">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="">
                    <!--                <div class="col-md-10" style="background: #F6F6F6;">-->
                    <div class="row" style="margin-bottom: -8px;">
                        <div class="col-md-4"><h4></h4>
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4"><!--<h4 style="float: right;"><i class="fa fa-question-circle" aria-hidden="true"></i> DISCLAIMER</h4>-->
                        </div>
                    </div>
                    <div id="showfbdiv" class="fbaddsshowresultdiv">
                        <?php $this->load->view('front/facebbokadds/fbShowDiv'); ?>
                    </div>
                    <div>
                        <div style="float: right; margin-top: 34px;">
                            <?php echo $showing; ?>
                        </div>
                        <div id="pagination"class="row text-center" style="float: left">
                            <ul class="tsc_pagination">
                                <?php echo $pagination; ?>
                            </ul>
                        </div>
                    </div>
                    <!--<div class="row text-center"><button loadbtn="8" class="btn btn-success show_more" style="width: 210px; height: 30px;">LOAD MORE</button></div><br>-->

                </div><!--/span-->
            </div><!--/span-->
        </div>
    </div>
<?php } ?>
<!------------FOR COUNT PAGE VIEW ---------------->
<script type="text/javascript">
    $(document).ready(function () {

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url() ?>accesspage',
            data: {'page_id': 3},
            success: function (data) {
                var obj = JSON.parse(data);
                console.log(obj.result);
                if (obj.result == 1) {
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url() ?>pagecount',
                        data: {'page_id': 3},
                        success: function (data) {
                        }
                    });
                } else {
                    location.href = "<?php echo base_url('permissionerror'); ?>";
                }
            }
        });



    });

</script>
<!--------------------------FOR AUTOCOMPLETE-------------------->
<script>
     $(function () {
        $("#banTag").autocomplete({
            source: "<?php echo base_url() ?>fbecoTagAutocomplete"
        });
    });
    
    $("#fbdrop").change(function () {
        var searchval = this.value;
        $.ajax({
            url: "<?php echo site_url('searchfbbyentries'); ?>",
            type: "post",
            data: {
                searchval: searchval
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                alert('hira');
                $('.fbaddsshowresultdiv').html(hhh.bannerdiv);
            }
        });
    });
    
    function fbsearch(){
   // $('#banTag').change(function () {
       var searchKey = $('#banTag').val();
      // alert(searchKey);
       $.ajax({
            url: "<?php echo site_url('searchfbecobyautokey'); ?>",
            type: "post",
            data: {
                searchKey: searchKey
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#showfbdiv').html(hhh.bannerdiv);
            }
        });
   // });
    }
    
    function searchbycategory(cat_id){
        $.ajax({
            url: "<?php echo site_url('searchfbbycatid'); ?>",
            type: "post",
            data: {
                cat_id: cat_id
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#showfbdiv').html(hhh.bannerdiv);
            }
        });
    }
    
    function searchbycountry(country_id){
        $.ajax({
            url: "<?php echo site_url('searchfbbycountryid'); ?>",
            type: "post",
            data: {
                country_id: country_id
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#showfbdiv').html(hhh.bannerdiv);
            }
        });
    }
    
     function searchbymyfavfb(member_id){
      $.ajax({
            url: "<?php echo site_url('searchfbbymyfav'); ?>",
            type: "post",
            data: {
                member_id: member_id,
                option_id: 3
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#showfbdiv').html(hhh.myfav);
            }
        });
    }
    
    function searchbymycomfb(member_id){
        $.ajax({
            url: "<?php echo site_url('searchfbbymycom'); ?>",
            type: "post",
            data: {
                member_id: member_id,
                option_id: 3
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#showfbdiv').html(hhh.mycom);
            }
        });
    }
    
    function showcommentbox(adds_id) {
        $.ajax({
            url: "<?php echo site_url('fbcommentmodal'); ?>",
            type: "post",
            data: {
                addsId: adds_id,
                option_id: 3
            },
            success: function (msg) {
                $('#bannercommentmodal').html(msg);
                $('.com_option_id').val(3);
                $('.com_adds_id').val(adds_id);
                $('#bannercommentmodal').modal('show');

            }
        });
    }
</script>