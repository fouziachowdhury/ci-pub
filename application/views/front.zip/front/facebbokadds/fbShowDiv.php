<div class="row demosrs" id='showfbaddsdata'>
    <section id="contentrs">
        <div id="container" class="clearfix" style="padding: 5px; margin-bottom: 20px; border-radius: 5px; clear: both; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; padding-top: 10px;">
            <div class="row">
                <div class="col-md-12">
                    <?php
                    $countryId = '';
                    if (!empty($allfbadds)) {
                        foreach ($allfbadds as $allfb) {
                            if (strpos($allfb['country_id'], ',') !== false) {
                                $countryArray = explode(',', $allfb['country_id']);
                                $getcountry = $this->LandingModel->getcountryinfo($countryArray);
                                $coun = '';
                                $counImg = '';
                                foreach ($getcountry as $ccc) {
                                    $coun[] = $ccc['country_name'];
                                    $counImg[] = $ccc['country_image'];
                                }
                                $countryName = implode(", ", $coun);
                                $countryImg = implode(", ", $counImg);
                            } else {
                                $getcountry = $this->LandingModel->getcountryimageinfo($allfb['country_id']);
                                $countryImg = $getcountry->country_image;
                                $countryName = $getcountry->country_name;
                            }
                            ?>
                            <?php
                            $categoryArray = explode(',', $allfb['cat_id']);
                            $getcategory = $this->LandingModel->getcategoryinfo($categoryArray);
                            //print_r($getcategory); exit; 
                            $string = array();
                            foreach ($getcategory as $cat) {
                                $string[] = $cat['cat_name'];
                            }
                            //print_r($string); exit;
                            $catName = implode(", ", $string);
                            ?>

                            <?php
                            $keywordArray = explode(',', $allfb['keyword']);
                            $getkeyword = $this->LandingModel->getkeywordinfo($keywordArray);
                            //print_r($getkeyword); exit; 
                            $string = array();
                            foreach ($getkeyword as $key) {
                                $string[] = $key['keyword_tags'];
                            }
                            //print_r($string); exit;
                            $key = implode(", ", $string);
                            ?>
                            <div class="col-md-6" style="background: #fff; margin-bottom: 17px;">
                                <div class="col-md-12">
                                    <?php echo $allfb['embedded_code']; ?> 
                                </div>

                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        Category : <?php echo $catName; ?>
                                    </div>
                                    <div class="col-md-12">
                                        <span style="font-size: 10px;" onclick="showcommentbox('<?php echo $allfb['id']; ?>');" id="landingcommbtn" landingddsid="<?php echo $allfb['id']; ?>" data-toggle="modal" data-target="#bannercommentmodal"><img data-toggle="tooltip" data-placement="bottom" title="Comment" src="<?php echo base_url() ?>assets/icon/comment.png" style="color:#3079C8; width: 16px;">  Comments</span>

                                        <?php if (in_array($allfb['id'], $favbanner)) { ?>
                                            <span style="font-size: 11px;"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" style="width: 16px; margin-left: 8px; margin-right: 8px;" src="<?php echo base_url() ?>assets/icon/favorites.png" style="color:red;width: 16px; font-size: 11px;">Favorite</span>
                                        <?php } else { ?>
                                            <a style="font-size: 11px;" href="<?php echo base_url() ?>makebannerfavorites/<?php echo $allfb['id']; ?>/3"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url() ?>assets/icon/favorites.png" style="width: 16px;font-size: 11px;">  Add To Favorite</a>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        Tags : <?php echo $key; ?>
                                    </div>
                                    <div class="col-md-12">

                                        <?php
                                        if (strpos($countryImg, ',') !== false) {
                                            $couimg = explode(',', $countryImg);
                                            ?>
                                            <span style="margin-top: 5px;">
                                                <?php foreach ($couimg as $cimg) { ?>
                                                    <img style="width:17px" src="<?php echo base_url() ?>assets/front/images/country_flag/<?php echo trim($cimg); ?>">
                                                <?php } ?>
                                            </span>
                                        <?php } else { ?>
                                            <span style="margin-top: 5px;"><img style="width:17px" src="<?php echo base_url() ?>assets/front/images/country_flag/<?php echo trim($countryImg); ?>"></span>

                                        <?php } ?>
                                    </div>
                                </div>






                                <div class="modal fade" tabindex="-1" role="dialog" id="bannercommentmodal"></div>




                            </div>

                            <?php
                        }
                    } else {
                        ?>
                    </div>
                </div>

                <div>
                    <h3 style="color:red">There is no data according your criteria !!!!</h3>
                </div>
            <?php } ?>
        </div>
        <div class="clearfix"></div> <br><br>
</div>



