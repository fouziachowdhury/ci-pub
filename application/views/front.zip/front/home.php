<section class="x-services ptb-100 gray-bg">
                <section class="section-title">
                    <div class="container text-center">
                        <h2>What We Offer</h2>
                        <span class="bordered-icon"><i class="fa fa-circle-thin"></i></span>
                    </div>
                </section>

                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="thumbnail clearfix">
                                <a href="#"><img class="img-responsive" src="<?php echo base_url() ?>/assets/front/images/template/img-offer-1.jpg" alt="Image"></a>

                                <div class="caption">
                                    <h3><a href="#">Investment</a></h3>

                                    <p>Praesent dapibus eleifend aug eget sollicitudin velit malesuada Aliquam blandit diam feugiat
                                        tellus odio malesuada ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="thumbnail clearfix">
                                <a href="#"><img class="img-responsive" src="<?php echo base_url() ?>/assets/front/images/template/img-offer-2.jpg" alt="Image"></a>

                                <div class="caption">
                                    <h3><a href="#">Planning</a></h3>

                                    <p>Praesent dapibus eleifend aug eget sollicitudin velit malesuada Aliquam blandit diam feugiat
                                        tellus odio malesuada ex.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- row -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="thumbnail clearfix">
                                <a href="#"><img class="img-responsive" src="<?php echo base_url() ?>/assets/front/images/template/img-offer-3.jpg" alt="Image"></a>

                                <div class="caption">
                                    <h3><a href="#">Analysis</a></h3>

                                    <p>Praesent dapibus eleifend aug eget sollicitudin velit malesuada Aliquam blandit diam feugiat
                                        tellus odio malesuada ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="thumbnail clearfix">
                                <a href="#"><img class="img-responsive" src="<?php echo base_url() ?>/assets/front/images/template/img-offer-4.jpg" alt="Image"></a>

                                <div class="caption">
                                    <h3><a href="#">Banking</a></h3>

                                    <p>Praesent dapibus eleifend aug eget sollicitudin velit malesuada Aliquam blandit diam feugiat
                                        tellus odio malesuada ex.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- .row -->
                </div>
                <!-- .container -->
            </section>
            <!-- .x-services -->


            <section class="testimonial">
                <section class="section-title">
                    <div class="container text-center">
                        <h2>Satisfied Customer</h2>
                        <span class="bordered-icon"><i class="fa fa-circle-thin"></i></span>
                    </div>
                </section>
                <div class="container">
                    <div id="testimonialSlider" class="carousel slide" data-ride="carousel">

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <blockquote>
                                    <ul>
                                        <li><img src="<?php echo base_url() ?>/assets/front/images/template/img-testimonial-1.jpg" class="img-responsive" alt=""/></li>
                                        <li class="name">Justus Kühn</li>
                                    </ul>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum egetvel </br>lacus
                                        pretium rhoncus a quis nisly Ut vehicula gravida dui in pulvinar donec</br> diam elit
                                        consequat eget augue vitae aliquet sollicitudin.
                                    </p>

                                </blockquote>
                            </div>
                            <div class="item">
                                <blockquote>
                                    <ul>
                                        <li><img src="<?php echo base_url() ?>/assets/front/images/template/img-testimonial-2.jpg" class=" img-responsive" alt=""/></li>
                                        <li class="name">Lennox Arnold</li>
                                    </ul>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum egetvel </br>lacus
                                        pretium rhoncus a quis nisly Ut vehicula gravida dui in pulvinar donec</br> diam elit
                                        consequat eget augue vitae aliquet sollicitudin.
                                    </p>

                                </blockquote>
                            </div>
                            <div class="item">
                                <blockquote>
                                    <ul>
                                        <li><img src="<?php echo base_url() ?>/assets/front/images/template/img-testimonial-3.jpg" class="img-responsive" alt=""/></li>
                                        <li class="name">Paulina Berger</li>
                                    </ul>

                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum egetvel </br>lacus
                                        pretium rhoncus a quis nisly Ut vehicula gravida dui in pulvinar donec</br> diam elit
                                        consequat eget augue vitae aliquet sollicitudin.
                                    </p>
                                </blockquote>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#testimonialSlider" role="button" data-slide="prev">
                            <span><i class="fa fa-angle-left"></i></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#testimonialSlider" role="button" data-slide="next">
                            <span><i class="fa fa-angle-right"></i></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                    <!-- #testimonialSlider -->
                </div>
            </section>
            <!-- .testimonial -->

            <section class="client-logo ptb-100">
                <section class="section-title">
                    <div class="container text-center">
                        <h2>Our Clients</h2>
                        <span class="bordered-icon"><i class="fa fa-circle-thin"></i></span>
                    </div>
                </section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="<?php echo base_url() ?>/assets/front/images/template/logo-client-1.jpg" alt="Image"></a>
                        </div>
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="<?php echo base_url() ?>/assets/front/images/template/logo-client-2.jpg" alt="Image"></a>
                        </div>
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="i<?php echo base_url() ?>/assets/front/images/template/logo-client-3.jpg" alt="Image"></a>
                        </div>
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="<?php echo base_url() ?>/assets/front/images/template/logo-client-4.jpg" alt="Image"></a>
                        </div>
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="<?php echo base_url() ?>/assets/front/images/template/logo-client-5.jpg" alt="Image"></a>
                        </div>
                        <div class="col-md-2 col-sm-4 col-xs-6 section-margin">
                            <a href="#"><img src="<?php echo base_url() ?>/assets/front/images/template/logo-client-6.jpg" alt="Image"></a>
                        </div>
                    </div>
                </div>
                <!--end of .container -->
            </section>
            <!-- /.client-logo -->


