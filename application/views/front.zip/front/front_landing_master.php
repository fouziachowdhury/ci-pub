<?php echo $headerlink; ?>
<body>
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>
        </svg>
    </div>
    <div id="wrapper">
        <?php echo $header; ?>
        <?php
        if (isset($sidebar)) {
            echo $sidebar;
        }
        ?><br><br><br>
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title" style="overflow: visible;">
                    <div class="col-lg-9 col-md-10 col-sm-10 col-xs-12">
                        <!--                        <h4 class="page-title"></h4>--> 
                        <ul class="list-unstyled list-inline" style="text-align: left;">
                            <li><h4>Filter By</h4></li>
                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Category
                                        <span class="fa fa-sort-desc"></span></button>
                                    <ul class="dropdown-menu dropdown-design">
                                        <?php foreach ($allcategory as $cat) { ?>
                                            <li value="<?php echo $cat['cat_id']; ?>"><a onclick="searchbycategory(<?php echo $cat['cat_id']; ?>)"><?php echo $cat['cat_name']; ?></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Country
                                        <span class="fa fa-sort-desc"></span></button>
                                    <ul class="dropdown-menu dropdown-design" style="height: 350px;overflow: auto;">
                                        <?php foreach ($allcountry as $country) { ?>
                                            <li value="<?php echo $country['country_id']; ?>"><a onclick="searchbycountry(<?php echo $country['country_id']; ?>)"><?php echo $country['country_name']; ?></a></li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">Display All
                                        <span class="fa fa-sort-desc"></span></button>
                                    <ul class="dropdown-menu dropdown-design" style="height: auto;overflow: auto;">
                                            <li><a onclick="searchbymyfav(<?php echo $_SESSION['member_id']; ?>)">My Favorites</a></li>
                                            <li><a onclick="searchbymycom(<?php echo $_SESSION['member_id']; ?>)">My Comments</a></li>
                                    </ul>
                                </div>
                            </li>
                             <input style="width: 110px;border-radius: 5%;" class="" placeholder="" aria-controls="myTable" type="text" id="landTag"><button onclick="landingsearch()" style="margin-left: 5px; height: 24px; padding-top: 2px; padding-bottom: 0px;" class="btn btn-info">Search</button>
                        </ul>
                    </div>
                    <!--<div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
                        <div id="myTable_filter" class="dataTables_filter"><input class="" placeholder="" aria-controls="myTable" type="text" id="landTag"><button onclick="landingsearch()" style="margin-left: 5px; height: 24px; padding-top: 2px; padding-bottom: 0px;" class="btn btn-info">Search</button></div>
                    </div>-->
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <div class="dataTables_length" id="myTable_length" style="float: right;">
                            <form method="get" id="dropdownlandsearch" name="dropdownlandsearch">
                                <label>Show <select name="myTable_length" aria-controls="myTable" class="" id="drop">
                                       <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="250">250</option>
                                        <option value="500">500</option>
                                    </select> entries</label>
                            </form>
                        </div>
                    </div>
                </div> 
                <?php echo $front_maincontent; ?>
                <?php echo $footer; ?>
            </div>
        </div>
        <?php echo $footerlink; ?>
</body>
</html>