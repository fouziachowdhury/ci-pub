<style type="text/css">

    * { margin: 0; padding: 0; }
    
    body {
      background-color: #000;
      background-image: url("<?php echo base_url()?>assets/front/images/error/404_background.jpg");
      width: 800px;
      height: 600px;
      margin-left: auto;
      margin-right: auto;
    }
    
    #text {
      display:none;
    }

</style>

<div id="text">404 Not Found</div>
<div class="image" style="position: relative; ">
    <img src="<?php echo base_url()?>assets/front/images/error/404.jpg" width="800" height="600">
<h2 style="position: absolute; top: 37px; left: 123px; width: 100%;">Please Login first to access this option..........<a href="<?php echo base_url()?>">BACK TO THE SITE</a></h2>
</div>