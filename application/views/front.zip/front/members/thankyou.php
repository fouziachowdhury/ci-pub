<section class="single-page-title">
    <div class="container text-center">
        <h2>Thank You....</h2>
    </div>
</section>
<!-- .page-title -->

<section class="about-text ptb-100">
    <section class="section-title">
        <div class="container text-center">
            <h2>Thank you for joining, <a href="<?php echo base_url()?>">PUBLYFE</a><h2>
                    <h2>Please confirm your email</h2>
            <span class="bordered-icon"><i class="fa fa-circle-thin"></i></span>
        </div>
    </section>
    <div class="container">
        <div class="row">
        </div>
    </div>

</section>
<!-- .about-text-->