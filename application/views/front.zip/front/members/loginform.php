<section class="single-page-title">
    <div class="container text-center">
        <h2>Login Form</h2>
    </div>
</section>
<!-- .page-title -->

<section class="about-text ptb-100">
    <section class="section-title">
        <div class="container text-center">
            <h2>If You Don't Have An Account Then Please <a href="<?php echo base_url()?>registrationform">SINGUP</a></h2>
            <span class="bordered-icon"><i class="fa fa-circle-thin"></i></span>
        </div>
    </section>
    <div class="container">
        <div class="row">

            <form id="member_login_form" method="post" role="form" style="display: block;" action="<?php echo base_url() ?>loginmember">
                <div class="form-group">
                    <input type="text" name="member_email" id="member_email" tabindex="1" class="form-control" placeholder="Email" value="<?php echo set_value('member_email'); ?>">
                    <?php if (form_error('member_email')) { ?>
                        <span style="color:red"><?php echo form_error('member_email'); ?></span>
                    <?php } ?>
                </div>
                <div class="form-group">
                    <input type="password" name="member_password" id="member_password" tabindex="2" class="form-control" placeholder="Password" value="<?php echo set_value('member_password'); ?>">
                    <?php if (form_error('member_password')) { ?>
                        <span style="color:red"><?php echo form_error('member_password'); ?></span>
                    <?php } ?>
                </div>
                <!--<div class="form-group">
                    <input type="checkbox" tabindex="3" class="" name="remember" id="remember">
                    <label for="remember"> Remember Me</label>
                </div>-->
                <div class="form-group">
                    <div class="row">
                        <input type="submit" name="login-submit" id="member_login_submit" tabindex="4" class="form-control btn btn-login btn-info btn-block" value="Log In">
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="text-center">
                                <a href="<?php echo base_url() ?>forgetpassword" tabindex="5" class="forgot-password">Forgot Password?</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

</section>
<!-- .about-text-->
<script type="text/javascript">

    jQuery().ready(function () {
        var v = jQuery("#member_login_form").validate({
            rules: {
                member_email: {
                    required: true,
                    email: true
                },
                member_password: {
                    required: true
                }
            },
            errorElement: "span",
            errorClass: "help-inline-error",
        });

        $("#member_login_submit").click(function () {
            if (v.form()) {
                //$("#loader").show();
                //setTimeout(function () {
                $("#member_login_form").submit();
                // }, 1000);
                return false;
            }
        });
    });
</script>  