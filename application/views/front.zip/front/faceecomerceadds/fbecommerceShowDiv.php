<style>
.cursoricon { cursor: pointer; cursor: hand;}
.cursoricon a:hover { cursor: pointer; cursor: hand;}
</style>
<div class="row demosrs" id='showbannerdata'>
    <section id="contentrs">
        <div id="container" class="clearfix" style="/*background: #FFF; */ padding: 5px; margin-bottom: 20px; border-radius: 5px; clear: both; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;">
             <div class="row">
            <?php
            if (!empty($allfbeco)) {
                foreach ($allfbeco as $fbeco) {
                    //echo '<pre>';
                   // print_r($fbeco); 
                    ?>
                    <?php
                    $categoryArray = explode(',', $fbeco['cat_id']);
                    $getcategory = $this->LandingModel->getcategoryinfo($categoryArray);
                    //print_r($getcategory); exit; 
                    $string = array();
                    foreach ($getcategory as $cat) {
                        $string[] = $cat['cat_name'];
                    }
                    //print_r($string); exit;
                    $catName = implode(", ", $string);
                    ?>
                   <?php
                    if (strpos($fbeco['country_id'], ',') !== false) {
                     $countryArray = explode(',', $fbeco['country_id']);
                    $getcountry = $this->LandingModel->getcountryinfo($countryArray);
                    $coun = '';
                    $counImg = '';
                    foreach ($getcountry as $ccc) {
                        $coun[] = $ccc['country_name'];
                        $counImg[] = $ccc['country_image'];
                    }
                    $countryName = implode(", ", $coun);
                    $countryImg = implode(", ", $counImg);
                    } else {
                        $getcountry = $this->LandingModel->getcountryimageinfo($fbeco['country_id']);
                        $countryImg = $getcountry->country_image;
                        $countryName = $getcountry->country_name;
                    }
                    ?>
                    
                    <?php
                        $keywordArray = explode(',', $fbeco['keyword']);
                        $getkeyword = $this->LandingModel->getkeywordinfo($keywordArray);
                        //print_r($getkeyword); exit; 
                        $string = array();
                        foreach ($getkeyword as $key) {
                            $string[] = $key['keyword_tags'];
                        }
                        //print_r($string); exit;
                        $key = implode(", ", $string);
                        ?>
                    <div class="col-md-6" style="margin: 5px;padding: 5px;background: #fff;font-size: 11px;line-height: 1.4em;float: left;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;border: 1px solid #ddd; width: 48%; padding-left: 13px;">
                   <?php if ($fbeco['facebook_image'] != '') {  ?>
                            <a class="thumbnail example-image-link" href="<?php echo base_url() ?>uploads/facebook_images/<?php echo $fbeco['facebook_image']; ?>" data-lightbox="example-set" data-title="Category : <?php echo $catName; ?><br> Country : <?php echo $countryName; ?>">
                                <img class="example-image" src="<?php echo base_url() ?>uploads/facebook_images/<?php echo $fbeco['facebook_image']; ?>" alt="">
                            </a>
                            <?php
                        } else {
                            echo $fbeco['embedded_code'];
                        }
                        ?>
                        <div class="col-md-12">
                            <div class="row">
                        <div class="col-md-6">
									Category : <?php echo $catName; ?>
								</div>
								<div class="col-md-6">
									<span style="float: right;">Tags : <?php echo $key; ?></span>
								</div>
								</div>
								<div class="row">
                        <span class="cursoricon" style="font-size: 10px;" onclick="showcommentbox('<?php echo $fbeco['fb_ecom_id']; ?>');" id="landingcommbtn" landingddsid="<?php echo $fbeco['fb_ecom_id']; ?>" data-toggle="modal" data-target="#bannercommentmodal"><img data-toggle="tooltip" data-placement="bottom" title="Comment" src="<?php echo base_url()?>assets/icon/comment.png" style="color:#3079C8; width: 16px;">  Comments</span>
                        <div class="modal fade" tabindex="-1" role="dialog" id="bannercommentmodal"></div>
                        <?php if (in_array($fbeco['fb_ecom_id'], $favbanner)) { ?>
                            <span class="cursoricon"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url()?>assets/icon/favorites.png" style="color:red;width: 16px;"></i> Favorite</span>
        <?php } else { ?>
                            <a class="cursoricon" href="<?php echo base_url() ?>makebannerfavorites/<?php echo $fbeco['fb_ecom_id']; ?>/4"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url()?>assets/icon/favorites.png" style="color:red;width: 16px;"></i>  Add To Favorite</a>
                    <?php } ?>
                        <?php
                            if (strpos($countryImg, ',') !== false) {
                                $couimg = explode(',', $countryImg);
                                ?>
                                <span style="float: right;margin-top: 5px; margin-right: 8px;">
                                    <?php foreach ($couimg as $cimg) { ?>
                                        <img style="width:17px;" src="<?php echo base_url() ?>assets/front/images/country_flag/<?php echo trim($cimg); ?>">
                                <?php } ?>
                                </span>
        <?php } else { ?>
                                <span style="float: right;margin-top: 5px; margin-right: 8px;"><img style="width:17px" src="<?php echo base_url() ?>assets/front/images/country_flag/<?php echo trim($countryImg); ?>"></span>

        <?php } ?>  

                        
                    </div>
                    </div>
                    </div>
        <?php
    }
} else {
    ?>
                  </div>
                <div>
                    <h3 style="color:red">There is no data according your criteria !!!!</h3>
                </div>
<?php } ?>
        </div>
        <div class="clearfix"></div> <br><br>
        </div>
      
        <script>
                    $(function () {
                        var $container = $('#container');
                        $container.imagesLoaded(function () {
                            $container.masonry({
                                itemSelector: '.box'
                            });
                        });

                    });
        </script>



