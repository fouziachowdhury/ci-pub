<div class="row">
    <div id="all_time" style="display: block;">
         <?php if ($this->session->flashdata('success')) { ?>
                            <div class="alert alert-success alert-dismissable">
                                <i class="fa fa-check-square-o"></i>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $this->session->flashdata('success'); ?>
                            </div>
                        <?php }
                        ?>

                        <?php if ($this->session->flashdata('error')) { ?>
                            <div class="alert alert-danger alert-dismissable">
                                <i class="fa fa-check-square-o"></i>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo $this->session->flashdata('error'); ?>
                            </div>

                        <?php }
                        ?>
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="row" id="afffeedshowdiv">
                <?php $this->load->view('front/affiliate/affiliatefeedPageDiv'); ?>
            </div>
            <div>
                <div style="float: right; margin-top: 34px;">
                    <?php echo $showing; ?>
                </div>
                <div id="pagination"class="row text-center" style="float: left">
                    <ul class="tsc_pagination">
                        <?php echo $pagination; ?>
                    </ul>
                </div>
            </div>
        </div><!--/span-->
    </div><!--/span-->
</div><!--/span-->


<script type="text/javascript">

    $(function () {
        $("#afffeedTag").autocomplete({
            source: "<?php echo base_url() ?>afffeedTagTagAutocomplete"
        });
    });
    
    
    $('#afffeedTag').change(function () {
       var searchKey = $('#afffeedTag').val();
      // alert(searchKey);
       $.ajax({
            url: "<?php echo site_url('searchafffeedTagbyautokey'); ?>",
            type: "post",
            data: {
                searchKey: searchKey
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#afffeedshowdiv').html(hhh.afffeeddiv);
            }
        });
    });
    
    function showcommentbox(adds_id) {
        $.ajax({
            url: "<?php echo site_url('feedcommentmodal'); ?>",
            type: "post",
            data: {
                addsId: adds_id,
                option_id: 6
            },
            success: function (msg) {
                $('#feedcommentmodal').html(msg);
                $('#com_option_id').val(6);
                $('#com_adds_id').val(adds_id);
                $('#feedcommentmodal').modal('show');
            }
        });
    }

    $("#offerdrop").change(function () {
        var searchval = this.value;
        //alert(searchval);
        $.ajax({
            url: "<?php echo site_url('searchafffeedbyentries'); ?>",
            type: "post",
            data: {
                searchval: searchval
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#afffeedshowdiv').html(hhh.afffeeddiv);
            }
        });
    });

function searchbymyfavoffer(member_id) {
        $.ajax({
            url: "<?php echo site_url('searchafffeedbymyfavoffer'); ?>",
            type: "post",
            data: {
                member_id: member_id,
                option_id: 7
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#afffeedshowdiv').html(hhh.myfav);
            }
        });
    }
    
    function searchbymycomoffer(member_id){
     $.ajax({
            url: "<?php echo site_url('searchafffeedbymycom'); ?>",
            type: "post",
            data: {
                member_id: member_id,
                option_id: 7
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#offerallshowdiv').html(hhh.mycom);
            }
        });
    }
    
    function searchbycategory(cat_id){
        $.ajax({
            url: "<?php echo site_url('searchafffeedbycatid'); ?>",
            type: "post",
            data: {
                cat_id: cat_id
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#afffeedshowdiv').html(hhh.afffeeddiv);
            }
        });
    }
    
    function searchbycountry(country_id){
        $.ajax({
            url: "<?php echo site_url('searchafffeedbycountryid'); ?>",
            type: "post",
            data: {
                country_id: country_id
            },
            success: function (msg) {
                var hhh = JSON.parse(msg);
                $('#afffeedshowdiv').html(hhh.afffeeddiv);
            }
        });
    }
    
</script>