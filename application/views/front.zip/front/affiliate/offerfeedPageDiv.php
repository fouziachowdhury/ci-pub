<style>
    .cursoricon a:hover { cursor: pointer; cursor: hand;}
    .favclass:hover { cursor: pointer; cursor: hand;}
    .commnetclass:hover { cursor: pointer; cursor: hand;}
    .whoisclass:hover { cursor: pointer; cursor: hand;}
    .contactclass:hover { cursor: pointer; cursor: hand;}
</style>
<div class="row demosrs" id='showfbaddsdata'>
    <section id="contentrs">
        <div id="container" class="clearfix" style="padding: 5px; margin-bottom: 20px; border-radius: 5px; clear: both; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;">
            <div class="row">
                <?php
                if (!empty($allofferfeed)) {
                    foreach ($allofferfeed as $offer) { 
                     $date = date("m-d-y", strtotime($offer['date'])); 
                        ?>
                        <div class="row" style="background: #fff; border: 1px solid #ddd; margin: 0 auto; margin-bottom: 20px;">
                            <div class="col-md-9 col-sm-12 col-xs-12" style=" margin-bottom: 10px;"> 
                                <div class="row">
                                    <div class="col-md-3">
                                        <a class="thumbnail" style="border:none" href="#"><img style="width:200px; float: left; border: 1px solid #ddd;" class="img-responsive" src="<?php echo $offer['zip_file_name']; ?>" alt=""></a>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="row" style=" margin-top:10px">
                                            <h4><?php echo $offer['title']; ?></h4>
                                        </div>
                                        <div class="row">
                                            <span style="float: left;">URL :</span><div class="col-md-11" style="border: 1px solid #ddd;">
                                                <p><?php
                                                  if (strlen($offer['url']) > 50) {
                                                        echo substr($offer['url'], 0, 80);
                                                      }   else {
                                                      echo $offer['url'];
                                                        }
                                                       ?>
                                                    
                                                   </p>
                                            </div>
                                        </div>
                                        <div class="row thumb" style="margin-top: 10px;margin-right: -7px;">
                                            <div>
                                                <?php if (in_array($offer['id'], $favbanner)) { ?>
                                                    <span class="favclass" style="margin-left: 10px; font-size: 10px;"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" style="width: 14px; font-size: 8px;" src="<?php echo base_url()  ?>assets/icon/favorites.png"> FAVORITES</span>
                                                <?php } else { ?>
                                                    <a class="favclass" style="font-size: 10px; margin-left: 10px; color: inherit;" href="<?php echo base_url()  ?>makebannerfavorites/<?php echo $offer['id'];  ?>/7"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url()  ?>assets/icon/favorites.png" style="width: 14px;"> ADD TO FAVORITES</a>
                                                <?php } ?> 
                                               <span class="commnetclass" style="font-size: 10px; margin-left: 10px;" onclick="showcommentbox('<?php echo $offer['id'];  ?>');" id="landingcommbtn" landingddsid="<?php echo $offer['id'];  ?>" data-toggle="modal" data-target="#offercommentmodal"><img data-toggle="tooltip" data-placement="bottom" title="Comment" src="<?php echo base_url()  ?>assets/icon/comment.png" style="color:#3079C8; width: 16px;">  COMMENTS</span>
                                                <div class="modal fade" tabindex="-1" role="dialog" id="offercommentmodal"></div>
                                               <span class="whoisclass" style="font-size: 10px; margin-left: 10px;"><a style="color: inherit;" href="<?php echo base_url()?>getwhoisinfo/<?php echo base64_encode($offer['url']); ?>"><img data-toggle="tooltip" data-placement="bottom" title="Whois" src="<?php echo base_url()  ?>assets/icon/whois.png" style="width: 16px;"> WHOIS</a></span>
                                                <span class="contactclass" style="font-size: 10px; margin-left: 10px;"><a style="color: inherit;" title="ImageName" onclick="showcontactbox('<?php echo base64_encode($offer['url']);  ?>');" data-toggle="modal" data-target="#whoiscontactmodal"><img data-toggle="tooltip" data-placement="bottom" title="Contact" src="<?php echo base_url()  ?>assets/icon/contact.png" style="width: 16px;" > CONTACT</a></span>
                                                <div class="modal fade" tabindex="-1" role="dialog" id="whoiscontactmodal"></div>
                                                <span style="font-size: 10px; float: right; margin-right: 23px;"><?php echo $date;?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-5 col-xs-5">
                                <div class="table-responsive" style="border: 1px solid #ddd; margin-right: 3px; margin-left: -11px;">
                                    <table id="myTable" class="table table-striped" style="font-size: 12px;">
                                        <thead>
                                        </thead>
                                        <tbody>
                                            <tr><td style="text-align: center; padding: 6px 6px;"><a href="<?php echo $offer['url'];    ?>" target="_blank">VIew Site</a></td></tr>
                                            <tr><td style="padding: 6px 6px;">Category :<?php
                                                    $categoryArray = explode(',', $offer['cat_id']);
                                                     $getcategory = $this->LandingModel->getcategoryinfo($categoryArray);
                                                     $string = '';
                                                     foreach ($getcategory as $cat) {
                                                      $string[] = $cat['cat_name'];
                                                      }
                                                      echo implode(", ", $string);
                                                    ?>
                                                </td></tr>
                                            <tr><td style="padding: 6px 6px;">Country : 
                                                    <?php
                                                     $countryArray = explode(',', $offer['country_id']);
                                                     $getcountry = $this->LandingModel->getcountryinfo($countryArray);
                                                     $coun = '';
                                                     foreach ($getcountry as $ccc) {
                                                        $coun[] = $ccc['country_name'];
                                                    }
                                                     echo implode(", ", $coun);
                                                    ?>
                                                </td></tr>
                                            <tr><td style="padding: 6px 6px;">Tag : 
                                                    <?php 
                                                    if(isset($offer['keyword'])) {
                                                    $keyArray = explode(',', $offer['keyword']);
                                                    $getkeyword = $this->LandingModel->getkeywordinfo($keyArray);
                                                    $k = '';
                                                    foreach ($getkeyword as $kkk) {
                                                        $k[] = $kkk['keyword_tags'];
                                                    }
                                                     $tags = implode(", ", $k);
                                                     if (isset($tags)) {
                                                        echo $tags;
                                                     }
                                                     }
                                                    ?></td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!--                                     </div>-->
                        <?php
                    }
                } else {
                    ?>
                </div>
                <div>
                    <h3 style="color:red">There is no data according your criteria !!!!</h3>
                </div>
            <?php } ?>
        </div>
        <div class="clearfix"></div>
</div>