<style>
.cursoricon { cursor: pointer; cursor: hand;}
.cursoricon a:hover { cursor: pointer; cursor: hand;}
</style>
<div class="alert alert-danger" id="downloaderror" style="display:none">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Danger!</strong> You have cross your limit of download this add. Renew your package Now.
</div>

<div class="row demosrs" id='showfbaddsdata'>
    <section id="contentrs">
        <div id="container" class="clearfix" style="padding: 5px; margin-bottom: 20px; border-radius: 5px; clear: both; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;">
            <div class="row">
                <?php
                if (!empty($allppv)) {
                    foreach ($allppv as $ppv) {
                        ?>
                        <!--                                <div class="white-box">-->
                        <div class="col-md-6" style="margin: 5px;width: 48%; margin-bottom: 25px;">
                            <div class="row" style="background: #fff; border: 1px solid #ddd;">
                                <div class="row">
                                    <div class="col-md-6 col-sm-12 col-xs-12"> 
                                        <a class="thumbnail" href="#" style="margin-top: 5px;margin-left: 5px; margin-bottom: 0px;"><img class="img-responsive" src="<?php echo $ppv['zip_file_name']; ?>" alt=""></a>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <h5 style="font-weight:bold">Title of the website</h5>
                                        <div class="table-responsive" style="border: 1px solid #ddd; margin-right: 3px; margin-left: -11px;">
                                            <table id="myTable" class="table table-striped" style="font-size: 12px;">
                                                <thead>
                                                </thead>
                                                <tbody>
                                                    <tr><td style="text-align: center; padding: 6px 6px;"><a href="<?php echo $ppv['url']; ?>" target="_blank">VIew Page</a></td></tr>
                                                    <tr><td style="padding: 6px 6px;">Category :<?php
                                                            $categoryArray = explode(',', $ppv['cat_id']);
                                                            $getcategory = $this->LandingModel->getcategoryinfo($categoryArray);
                                                            $string = '';
                                                            foreach ($getcategory as $cat) {
                                                                $string[] = $cat['cat_name'];
                                                            }
                                                            echo implode(", ", $string);
                                                            ?>
                                                        </td></tr>
                                                    <tr><td style="padding: 6px 6px;">Country : 
                                                            <?php
                                                            $countryArray = explode(',', $ppv['country_id']);
                                                            $getcountry = $this->LandingModel->getcountryinfo($countryArray);
                                                            //print_r($getcountry); exit;
                                                            $coun = '';
                                                            foreach ($getcountry as $ccc) {
                                                                $coun[] = $ccc['country_name'];
                                                            }
                                                            echo implode(", ", $coun);
                                                            ?>
                                                        </td></tr>
                                                    <tr><td style="padding: 6px 6px;">Tag : 
                                                            <?php
                                                            $keyArray = explode(',', $ppv['keyword']);
                                                            $getkeyword = $this->LandingModel->getkeywordinfo($keyArray);
                                                            //print_r($getkeyword); exit;
                                                            $k = '';
                                                            foreach ($getkeyword as $kkk) {
                                                                $k[] = $kkk['keyword_tags'];
                                                            }
                                                            //print_r($k); 
                                                            $tags = implode(", ", $k);
                                                            if (isset($tags)) {
                                                                echo $tags;
                                                            }
                                                            ?></td></tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div>
                                            <span class="cursoricon" style="font-size: 10px;" onclick="showcommentbox('<?php echo $ppv['ppv_id']; ?>');" id="landingcommbtn" landingddsid="<?php echo $ppv['ppv_id']; ?>" data-toggle="modal" data-target="#ppvcommentmodal"><img data-toggle="tooltip" data-placement="bottom" title="Comment" src="<?php echo base_url()?>assets/icon/comment.png" style="color:#3079C8; width: 16px;"> Comments </span>
                                            <div class="modal fade" tabindex="-1" role="dialog" id="ppvcommentmodal"></div>
                                            <?php if (in_array($ppv['ppv_id'], $favbanner)) { ?>
                                                <span class="cursoricon" style="font-size: 10px;"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url()?>assets/icon/favorites.png" style="color:red;width: 16px;">Add To Favorite</span>
                                            <?php } else { ?>
                                                <a class="cursoricon" style="font-size: 10px;" href="<?php echo base_url() ?>makebannerfavorites/<?php echo $ppv['ppv_id']; ?>/13"><img data-toggle="tooltip" data-placement="bottom" title="Favorites" src="<?php echo base_url()?>assets/icon/favorites.png" style="color:red;width: 16px;">Add To Favorite</a>
                                            <?php } ?>

                                          <span class="cursoricon" style="margin-left: 7px;font-size: 10px;"> 
                                                <a onclick="bannerdownload('<?php echo $ppv['ppv_id']; ?>')" title="ImageName"><img data-toggle="tooltip" data-placement="bottom" title="Download" src="<?php echo base_url()?>assets/icon/download.png" style="width: 16px;"> Download</a>
                                            </span>
                                          <a hidden id="download_<?php echo $ppv['ppv_id']?>" onclick="bannimgdown('<?php echo $ppv['ppv_id']?>')" download="<?php echo $ppv['zip_file_name']; ?>" href="<?php echo $ppv['zip_file_name']; ?>"><img data-toggle="tooltip" data-placement="bottom" title="Download" src="<?php echo base_url() ?>assets/icon/download.png" style="width: 16px;"></a>
                                             <input type="hidden" id="bannerid_<?php echo $ppv['ppv_id']?>" name="banneridtext" value="<?php echo $ppv['ppv_id']; ?>">
                                        </div> 
                                    </div>
                                </div>
                                <h4 style="text-align: center;font-weight: bold;">

                                </h4>


                            </div>
                        </div>
                    <?php
                    }
                } else {
                    ?>
                </div>
                <div>
                    <h3 style="color:red">There is no data according your criteria !!!!</h3>
                </div>
<?php } ?>
        </div>
        <div class="clearfix"></div>
</div>

<script>
     function bannerdownload(item_id) {
                var option_id = 5;
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url() ?>downloadcheck',
                    data: {
                        'item_id': item_id,
                        'option_id': option_id
                    },
                    success: function (result) {
                        var hhh = JSON.parse(result);
                        if (hhh.downloadresult == 1) {
                            var bannerimage = hhh.bannerimage;
                            var bannerimagehref = "<?php echo base_url() ?>uploads/banner_images/" + bannerimage;
                            document.getElementById('download_' + item_id).click();

                        } else if (hhh.downloadresult == 0) {
                            $('#downloaderror').show();
                            setInterval(function () {
                                $('#downloaderror').hide();
                            }, 50000);

                        }
                    }
                });
            }

            function bannimgdown(item_id) {
                var bannerid = $("#bannerid_" + item_id).val();
                var option_id = 5;
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url() ?>downloadnumberadd',
                    data: {
                        'item_id': bannerid,
                        'option_id': option_id
                    },
                    success: function (result) {
                        console.log(result);
                    }
                });
            }
</script>    